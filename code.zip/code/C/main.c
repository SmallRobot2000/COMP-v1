#include<stdint.h>
#include<stdio.h>
#include<string.h>
//#include<malloc.h>
//extern void putmchar(char a);
int i = 9;
uint8_t bytearr[256];
uint8_t *pointer;
char str1[] = "Lol";
int main()
{
    //putmchar(i);
    //putmchar('A');
    //bytearr = malloc();
    //printf("Alo");
    //strcpy(bytearr, str1);
    //pointer = malloc(0x4693);
    //sprintf( bytearr, "Idk %d", i);
    //memcpy(bytearr,str1,sizeof(str1));
    printf("Alooo ha %d",i);
    return 5;
}